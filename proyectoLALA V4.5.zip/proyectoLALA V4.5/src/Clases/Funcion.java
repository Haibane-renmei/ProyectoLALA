/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultListModel;
import javax.swing.InputVerifier;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumnModel;

/**
 *
 * @author macana
 */
public class Funcion {
    
    public Exportar exp;
    public float[][] est;

    public Funcion() {
        this.exp = new Exportar();
        est= new float[255][8];
    }

    
    
    
    
    public String ObtenerRif( String razonSo ) {
        conectar cc = new conectar();
        Connection cn = cc.conexion();
         
        
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery("SELECT rif_codigo FROM cliente WHERE razon_social='"+razonSo+"';");
         
            if( !rs.next() ){
                return null;
            }
            else{
                return rs.getString("rif_codigo");
            }

        }
        catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
        }
        catch( java.lang.NumberFormatException e){
                   System.out.println("eror en "+e.toString());
        }  
              
       return null; 
    }
    
    
public static void reiniciarJTable(javax.swing.JTable Tabla){
        DefaultTableModel modelo = (DefaultTableModel) Tabla.getModel();
        while(modelo.getRowCount()>0)modelo.removeRow(0);
 
        TableColumnModel modCol = Tabla.getColumnModel();
        while(modCol.getColumnCount()>0)modCol.removeColumn(modCol.getColumn(0));
}
    
public void listarDatosCliente( String rif, String razonSo,JLabel razonn, JLabel contacto,JLabel tlf,JLabel monto,JLabel montoo, JLabel Rif, JLabel Direccion)
 {
              conectar cc = new conectar();
                Connection cn = cc.conexion();
                try {
                    Statement st = cn.createStatement();
                    ResultSet rs = st.executeQuery("SELECT contacto,telefonos,limite_de_credito, credito_disponible, direccion from cliente Where rif_codigo='"+rif+"' AND razon_social='"+razonSo+"';");
                    while(rs.next()){
                        razonn.setText(razonSo);
                        String contac = rs.getString("contacto");
                        contacto.setText(contac);
                        String telf = rs.getString("telefonos");
                        tlf.setText(telf);
                          String montoC = rs.getString("limite_de_credito");
                          monto.setText(montoC);
                          String montoD = rs.getString("credito_disponible");
                          montoo.setText(montoD);
                        Direccion.setText(rs.getString("Direccion"));
                        Rif.setText(rif);
                        
                        
                       
                            
                    }

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("eror en "+e.toString());
               }  
              
              
         }
    
    public void listarDatosClienteNombre( String razonSo,JLabel razonn, JLabel contacto,JLabel tlf,JLabel monto,JLabel montoo, JLabel Rif, JLabel Direccion)
 {
              conectar cc = new conectar();
                Connection cn = cc.conexion();
                try {
                    Statement st = cn.createStatement();
                    ResultSet rs = st.executeQuery("SELECT rif_codigo,contacto,telefonos,limite_de_credito, credito_disponible, direccion from cliente Where  razon_social='"+razonSo+"';");
                    while(rs.next()){
                        razonn.setText(razonSo);
                        String contac = rs.getString("contacto");
                        contacto.setText(contac);
                        String telf = rs.getString("telefonos");
                        tlf.setText(telf);
                          String montoC = rs.getString("limite_de_credito");
                          monto.setText(montoC);
                          String montoD = rs.getString("credito_disponible");
                          montoo.setText(montoD);
                        Direccion.setText(rs.getString("Direccion"));
                        Rif.setText(rs.getString("rif_codigo"));
                        
                        
                       
                            
                    }

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("eror en "+e.toString());
               }  
              
              
         }
    
public void ResetearLabelCliente( JLabel razonn, JLabel contacto,JLabel tlf,JLabel monto,JLabel montoo, JLabel Rif, JLabel Direccion){
  razonn.setText("");
  contacto.setText("");
  tlf.setText("");
  monto.setText("");
  montoo.setText("");
  Direccion.setText("");
  Rif.setText("");
  }
  
    
public void listarProductos(JTable tablaProductos)
    {
     DefaultTableModel model;
    String [] titulos={"codigo producto", "nombre producto","cantidad"};
    String [] registros = new String [3];
           model= new DefaultTableModel(null,titulos){
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
           
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery( "SELECT pr.codigo_producto as cp , pr.nombre_producto as np,(SUM(pl.cantidad_x_lote)-R.cantidad_reservada) as pll\n" +
"FROM producto as pr, lote_producto as pl, productos_reservados as R\n" +
"WHERE pr.codigo_producto= pl.codigo_producto\n" +
"AND   pr.codigo_producto = R.codigo_producto\n" +
"GROUP BY pl.codigo_producto,pr.nombre_producto\n" +
"\n" +
"UNION ALL \n" +
"SELECT pr.codigo_producto, pr.nombre_producto,SUM(pl.cantidad_x_lote) as pll\n" +
"FROM producto as pr inner join lote_producto as pl ON (pr.codigo_producto = pl.codigo_producto)\n" +
"left join productos_reservados as R ON ( pr.codigo_producto = R.codigo_producto )\n" +
"WHERE  R.codigo_producto IS NULL \n" +
"GROUP BY pr.codigo_producto, pr.nombre_producto\n" +
"order by pll desc"
                );
                while(rs.next()){
                    registros[0]= rs.getString("cp");
                    registros[1]=rs.getString("np");
                     registros[2]=rs.getString("pll");
                     model.addRow(registros);
                                }
                tablaProductos.setModel(model);
                tablaProductos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en void listarProductos "+e.toString());
               }
                     //PARA DAR TAMAÑO ESPECIFICO A LAS COLUMNAS DE UNA TABLA
 
    }


public void listarEstadisticaAMD(JTable tablaEstadistica, String fechaI,String fechaF) throws IOException
    {
     DefaultTableModel model;
    String [] titulos={"Producto", "Demanda","Oferta"};
    String [] registros = new String [3];
           model= new DefaultTableModel(null,titulos){
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
           
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery( "select p.nombre_producto, SUM(resultado.oferta) as oferta, SUM(resultado.demanda) as demanda\n" +
                                                "from producto as p, \n" +
                                                "(Select OL.codigo_producto, Sum(OL.cantidad) as oferta, 0 as demanda\n" +
                                                "From orden_x_lote as OL , orden_venta as OV\n" +
                                                "WHERE OL.orden_id = OV.id\n" +
                                                "AND OV.Hora>='"+fechaI+" 00:00:00'\n" +
                                                "AND OV.Hora<'"+fechaF+" 23:59:59'\n" +
                                                "Group by OL.codigo_producto, OV.hora\n" +
                                                "union all \n" +
                                                "Select D.codigo_producto, 0 as oferta, SUM(D.cantidad) as demanda\n" +
                                                "From estadisticas_demanda_productos as D \n" + 
                                                "WHERE D.fecha>='"+fechaI+" 00:00:00'\n" +
                                                "AND D.fecha<'"+fechaF+" 23:59:59'\n" + 
                                                "group by codigo_producto"+    
                                                ") as resultado\n" +
                                         "where resultado.codigo_producto = p.codigo_producto "+
                                         "Group by p.nombre_producto"
                );
                
                System.out.println(fechaI+" - "+fechaF );
                
                while(rs.next()){
                    registros[0]= rs.getString("nombre_producto");
                    registros[1]=rs.getString("demanda");
                     registros[2]=rs.getString("oferta");
                     exp.ingresarDatos(registros, 0);
                     model.addRow(registros);
                                }
                tablaEstadistica.setModel(model);
                tablaEstadistica.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                
                tablaEstadistica.getColumnModel().getColumn(1).setPreferredWidth(70);
                tablaEstadistica.getColumnModel().getColumn(1).setMinWidth(70);
                tablaEstadistica.getColumnModel().getColumn(1).setMaxWidth(70);
                tablaEstadistica.getColumnModel().getColumn(2).setPreferredWidth(70);
                tablaEstadistica.getColumnModel().getColumn(2).setMinWidth(70);
                tablaEstadistica.getColumnModel().getColumn(2).setMaxWidth(70);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en void listarProductos "+e.toString());
               }
    }

public void listarLlamadas(JTable tablaEstadistica, String fechaI, String fechaF){
    DefaultTableModel model;
    String [] titulos={ "ID", "Operadora", "Cliente", "Direccion","Fecha y Hora", "exitosa", "Vendido"};
    String [] registros = new String [7];
           model= new DefaultTableModel(null,titulos){
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
           
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery( "SELECT rl.codigo_llamada, u.nombre_completo, c.razon_social, c.direccion, rl.fecha_llamada, rl.hora_llamada, rl.exitosa, rl.monto_venta_contado\n" +
                                                "FROM registro_llamadas as rl, cliente as c, usuarios as u\n" +
                                                "WHERE rl.usuario = u.id\n" +
                                                "AND rl.rif_codigo = c.rif_codigo\n" +
                                                "AND str_to_date(rl.fecha_llamada,'%d-%m-%Y') >= '"+fechaI+"'\n" +
                                                "AND str_to_date(rl.fecha_llamada,'%d-%m-%Y') <= '"+fechaF+"'" 

                );
                
                System.out.println(fechaI+" - "+fechaF );
                
                while(rs.next()){
                    registros[0]= rs.getString("codigo_llamada");
                    registros[1]=rs.getString("nombre_completo");
                    registros[2]=rs.getString("razon_social");
                    registros[3]= rs.getString("direccion");
                    registros[4]= rs.getString("fecha_llamada")+" "+rs.getString("hora_llamada") ;
                    registros[5]=rs.getInt("exitosa")== 1 ? "si" : "no";
                    registros[6]=rs.getString("monto_venta_contado");

                    
                     model.addRow(registros);
                     
                }
                
                tablaEstadistica.setModel(model);
                tablaEstadistica.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                
                tablaEstadistica.getColumnModel().getColumn(0).setPreferredWidth(55);           
                tablaEstadistica.getColumnModel().getColumn(0).setMinWidth(55);
                tablaEstadistica.getColumnModel().getColumn(0).setMaxWidth(55);
                tablaEstadistica.getColumnModel().getColumn(1).setPreferredWidth(115);
                tablaEstadistica.getColumnModel().getColumn(1).setMinWidth(115);
                tablaEstadistica.getColumnModel().getColumn(1).setMaxWidth(115);
                tablaEstadistica.getColumnModel().getColumn(4).setPreferredWidth(125);           
                tablaEstadistica.getColumnModel().getColumn(4).setMinWidth(125);
                tablaEstadistica.getColumnModel().getColumn(4).setMaxWidth(125);
                tablaEstadistica.getColumnModel().getColumn(5).setPreferredWidth(50);
                tablaEstadistica.getColumnModel().getColumn(5).setMinWidth(50);
                tablaEstadistica.getColumnModel().getColumn(5).setMaxWidth(50);
                tablaEstadistica.getColumnModel().getColumn(6).setPreferredWidth(85);
                tablaEstadistica.getColumnModel().getColumn(6).setMinWidth(85);
                tablaEstadistica.getColumnModel().getColumn(6).setMaxWidth(85);
                
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en void listarProductos "+e.toString());
               } 
    }


public void listarEstadisticaOpAMD(JTable tablaEstadistica, String fechaI,String fechaF) throws IOException
    {
     DefaultTableModel model;
     String [] titulos={"id", "Nombre","Llamadas","Exitosas","% Exito", "vendido (Bs)"};
     String [] registros = new String [6];
           model= new DefaultTableModel(null,titulos){
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
           
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery( "SELECT u.id, u.nombre_completo, count(rl.codigo_llamada) as llamadas, count(case rl.exitosa when 1 then 1 else null end) as exitosas, sum(rl.monto_venta_contado) AS  total_vendido\n" +
                                                "FROM usuarios AS u, registro_llamadas as rl\n" +
                                                "WHERE u.aplicacion = 1 \n" +
                                                "AND u.id = rl.usuario\n" +
                                                "AND rl.fecha_llamada >= '"+fechaI+"' \n" +
                                                "AND rl.fecha_llamada < '"+fechaF+"' \n" +
                                                "GROUP BY u.id, u.nombre_completo\n" +

                                                "union all \n" +

                                                 "SELECT u.id, u.nombre_completo, 0 as llamadas, 0 as exitosas, 0 as total_vendido \n" +
                                                "FROM usuarios as u Left join  registro_llamadas as rl on ( u.id = rl.usuario "+
                                                "AND rl.fecha_llamada >= '"+fechaI+"'  \n" +
                                                "AND rl.fecha_llamada < '"+fechaF+"'  "+
                                                 ")\n" +
                                                "WHERE u.aplicacion = 1\n" +
                                                "AND rl.usuario IS NULl\n" 
                );
                
                System.out.println(fechaI+" - "+fechaF );
                
                while(rs.next()){
                    registros[0]= rs.getString("id");
                    registros[1]=rs.getString("nombre_completo");
                    registros[2]=rs.getString("llamadas");
                    registros[3]= rs.getString("exitosas");
                    registros[4]=String.format("%.1f",(Double.parseDouble(rs.getString("exitosas"))/Double.parseDouble(rs.getString("llamadas")))*100)+"%";
                    registros[5]=rs.getString("total_vendido");
                    exp.ingresarDatos(registros, 1);
                     model.addRow(registros);
                     
                }
                tablaEstadistica.setModel(model);
                tablaEstadistica.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                
                tablaEstadistica.getColumnModel().getColumn(0).setPreferredWidth(30);           
                tablaEstadistica.getColumnModel().getColumn(0).setMinWidth(30);
                tablaEstadistica.getColumnModel().getColumn(0).setMaxWidth(30);
                tablaEstadistica.getColumnModel().getColumn(2).setPreferredWidth(70);
                tablaEstadistica.getColumnModel().getColumn(2).setMinWidth(70);
                tablaEstadistica.getColumnModel().getColumn(2).setMaxWidth(70);
                tablaEstadistica.getColumnModel().getColumn(3).setPreferredWidth(60);           
                tablaEstadistica.getColumnModel().getColumn(3).setMinWidth(60);
                tablaEstadistica.getColumnModel().getColumn(3).setMaxWidth(60);
                tablaEstadistica.getColumnModel().getColumn(4).setPreferredWidth(60);
                tablaEstadistica.getColumnModel().getColumn(4).setMinWidth(60);
                tablaEstadistica.getColumnModel().getColumn(4).setMaxWidth(60);
                tablaEstadistica.getColumnModel().getColumn(5).setPreferredWidth(85);
                tablaEstadistica.getColumnModel().getColumn(5).setMinWidth(85);
                tablaEstadistica.getColumnModel().getColumn(5).setMaxWidth(85);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en void listarProductos "+e.toString());
               }
    }



public void AñadirProductoTabla(JTable t,String cod,String nombre)
{
    if (ProductoDuplicado(cod, t)){
            JOptionPane.showMessageDialog(t,"El producto ya se encuentra en la tabla de producto demandados");
    }else{
            String [] registros = new String [3];
            registros[0]=cod;
            registros[1]="0";
            registros[2]=nombre;

            ((DefaultTableModel)t.getModel()).addRow(registros);
            
            int lastRow = t.convertRowIndexToView(t.getModel().getRowCount() - 1);
            t.setRowSelectionInterval(lastRow, lastRow);
           
            t.editCellAt(lastRow, 1);
            t.getEditorComponent().requestFocus();
            
           
            
            
           
    }
}

public int ObtenerCantidadAdespachar(JTable tabla, String CodigoProducto){
    
    DefaultTableModel model = (DefaultTableModel)tabla.getModel();
    
    int rows = model.getRowCount(); 
    int cantidad=0;
    System.out.println("deb: "+rows);
    for(int i = rows - 1; i >=0; i--){
            String CodigoP = ObtenerProductoDeLote(tabla.getModel().getValueAt(i, 1).toString());
            
            if (CodigoProducto.equals(CodigoP)){
                cantidad = cantidad + Integer.parseInt(tabla.getModel().getValueAt(i, 2).toString());
            }
    } 
    
    return cantidad;
}


public void listarCliente(JTable tablaListadoClientes, int Operadora)
    {
    DefaultTableModel model;
        String [] titulos={"RIF","RAZON SOCIAL","DIRECCION", "ULT. LLAMADA"};
        String [] registros = new String [4];
    

           model= new DefaultTableModel(null,titulos){

                
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
          
           };    System.out.println("ss"+model.getColumnCount());

           
           
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT c.rif_codigo, c.razon_social, c.direccion FROM cliente as c, operadora_x_cliente as oc WHERE oc.operadora = "+Operadora+"  AND oc.rif_codigo = c.rif_codigo ORDER BY razon_social asc;");
                while(rs.next()){
                    registros[0]= rs.getString("rif_codigo");
                    registros[1]=rs.getString("razon_social");
                     registros[2]=rs.getString("direccion");
                     registros[3]= new Funcion().ObtenerUltimaLlamadaFecha(rs.getString("rif_codigo"), rs.getString("direccion"));
                     
                     
                     model.addRow(registros);
                                }
                tablaListadoClientes.setModel(model);
                tablaListadoClientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                tablaListadoClientes.setDefaultRenderer(Object.class, new DefaultTableCellRenderer(){
                            @Override
                            public Component getTableCellRendererComponent(JTable table,
                                    Object value, boolean isSelected, boolean hasFocus, int row, int col) {


                                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);


                                String fecha = (String)table.getModel().getValueAt(row, 3);

                                if ("--".equals(fecha)  ) {
                                    setBackground(Color.getHSBColor(240, 130, 160));
                                    setForeground(Color.BLACK);
                                } else {
                                    
                                    
                                    Calendar c = Calendar.getInstance();
                                    
                                    c.setFirstDayOfWeek(Calendar.MONDAY);
                                    c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                                    c.set(Calendar.HOUR_OF_DAY, 0);
                                    c.set(Calendar.MINUTE, 0);
                                    c.set(Calendar.SECOND, 0);
                                    c.set(Calendar.MILLISECOND, 0);
                                    
                                    Date lunes = c.getTime();
                                    
                                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

                                    Date fechaLlamada;
                                    
                                    
                                    try{ fechaLlamada= sdf.parse(fecha);}
                                    catch (Exception e){ e.printStackTrace(); fechaLlamada= null; }

                                    
                                    if( fechaLlamada.before(lunes) ){
                                        setBackground(Color.getHSBColor(240, 130, 160));
                                        setForeground(Color.BLACK);
                                    }else{
                                        setBackground(table.getBackground());
                                        setForeground(table.getForeground());
                                    }
                                }  
                                
                                if (isSelected){
                                    setBackground(Color.BLUE);
                                    setForeground(Color.WHITE);
                                }
                                
                                return this;
                            }   
                });
              } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error number format  producido en void listarCliente"+e.toString());
               }
            catch( java.lang.NullPointerException e)
               {
                   System.out.println("error null pointer producido en void listarCliente"+e.toString());
               }
}


public String ObtenerUltimaLlamada(String rif, String direccion){
    
    conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT ultima_llamada FROM ultimas_llamadas where rif_codigo = '"+rif+"' and direccion = '"+direccion+"'  ");
                if (rs.next()) {
                    return rs.getString("ultima_llamada");
                }
                else{
                    return "--";
                }
                   
            } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                 
            }
            catch( java.lang.NumberFormatException e)
            {
                   System.out.println("error producido en void listarCliente3"+e.toString());
                   
            }
            return "--";
}

public String ObtenerUltimaLlamadaFecha(String rif, String direccion){
    
    conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT ultima_llamada FROM ultimas_llamadas where rif_codigo = '"+rif+"' and direccion = '"+direccion+"'  ");
                if (rs.next()) {
                    String fecha = rs.getString("ultima_llamada");
                    return fecha.substring(0, fecha.indexOf(" "));
                }
                else{
                    return "--";
                }
                   
            } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                 
            }
            catch( java.lang.NumberFormatException e)
            {
                   System.out.println("error producido en void listarCliente4"+e.toString());
                   
            }
            return "--";
}

public void listarProductosOV(JTable DetallesOrdenTable, String idOrden ){
     
         DefaultTableModel model;
         String [] titulos={ "lote" , "Codigo Producto", "Producto" , "Cantidad" };
         String [] registros = new String [4];
     
            model= new DefaultTableModel(null,titulos) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            
            try {
                Statement st = cn.createStatement();
                
                ResultSet rs = st.executeQuery("SELECT OL.correlativo_lote, OL.codigo_producto, OL.cantidad, P.nombre_producto FROM orden_x_lote as OL, producto as P WHERE P.codigo_producto = OL.codigo_producto AND Orden_id = "+idOrden);
                
                while(rs.next()){
                      
                        registros[0]=rs.getString("correlativo_lote");                    
                        registros[1]=rs.getString("codigo_producto");
                        registros[2]=rs.getString("nombre_producto");
                        registros[3]=rs.getString("cantidad");

                        model.addRow(registros);                          
                  
                }
                DetallesOrdenTable.setModel(model);
                DetallesOrdenTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                
                 DetallesOrdenTable.getColumnModel().getColumn(3).setPreferredWidth(65);
                 DetallesOrdenTable.getColumnModel().getColumn(3).setMinWidth(65);
                 DetallesOrdenTable.getColumnModel().getColumn(3).setMaxWidth(65);
                 
                 DetallesOrdenTable.getColumnModel().getColumn(0).setPreferredWidth(120);
                 DetallesOrdenTable.getColumnModel().getColumn(0).setMinWidth(120);
                 DetallesOrdenTable.getColumnModel().getColumn(0).setMaxWidth(120);
                 
                 DetallesOrdenTable.getColumnModel().getColumn(1).setPreferredWidth(120);
                 DetallesOrdenTable.getColumnModel().getColumn(1).setMinWidth(120);
                 DetallesOrdenTable.getColumnModel().getColumn(1).setMaxWidth(120);
                 
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en void listarCliente5"+e.toString());
               }
     
}
     
public void listarOrdenes(JTable tablaOrdenes)
    {
     DefaultTableModel model;
     String [] titulos={"ID", "Cliente","Rif","Direccion","Fecha y hora", "Operadora"};
     String [] registros = new String [6];
     
            model= new DefaultTableModel(null,titulos) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            
            try {
                Statement st = cn.createStatement();
                
                ResultSet rs = st.executeQuery(
                        
                          "SELECT orden_venta.id, orden_venta.cliente_rif , orden_venta.cliente_direccion , orden_venta.Hora, orden_venta.Despachado, usuarios.nombre_completo, cliente.razon_social "
                        + "FROM orden_venta, usuarios, cliente "
                        + "WHERE usuarios.id = orden_venta.operadora_id "
                        + "AND orden_venta.cliente_rif = cliente.rif_codigo order by orden_venta.Hora "
                        //+ "AND orden_venta.cliente_direccion= cliente.direccion "
                        
                        
                );
                
                while(rs.next()){
                    
                  if ( rs.getInt("despachado") == 0){  
                      
                        registros[0]=rs.getString("orden_venta.id");                    
                        registros[1]=rs.getString("cliente.razon_social");
                        registros[2]=rs.getString("orden_venta.cliente_rif");
                        registros[3]=rs.getString("orden_venta.cliente_direccion");
                        registros[4]=rs.getString("orden_venta.Hora");
                        registros[5]=rs.getString("usuarios.nombre_completo");
                        model.addRow(registros);
                        
                  }    
                  
                }
                tablaOrdenes.setModel(model);
                tablaOrdenes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en void listarCliente"+e.toString());
               }
  //codigo
  tablaOrdenes.getColumnModel().getColumn(0).setPreferredWidth(45);
  tablaOrdenes.getColumnModel().getColumn(0).setMinWidth(45);
   tablaOrdenes.getColumnModel().getColumn(0).setMaxWidth(45);
   //rif
   tablaOrdenes.getColumnModel().getColumn(2).setPreferredWidth(100);
  tablaOrdenes.getColumnModel().getColumn(2).setMinWidth(100);
   tablaOrdenes.getColumnModel().getColumn(2).setMaxWidth(100);
   //hora y fecha
   tablaOrdenes.getColumnModel().getColumn(4).setPreferredWidth(150);
  tablaOrdenes.getColumnModel().getColumn(4).setMinWidth(150);
   tablaOrdenes.getColumnModel().getColumn(4).setMaxWidth(150);
    }
 
public void listarOrdenesPasadas(JTable tablaOrdenes)
    {
     DefaultTableModel model;
     String [] titulos={"ID", "Cliente","Rif","Direccion","Fecha y hora", "Operadora"};
     String [] registros = new String [6];
     
            model= new DefaultTableModel(null,titulos) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            
            try {
                Statement st = cn.createStatement();
                
                ResultSet rs = st.executeQuery(
                        
                          "SELECT orden_venta.id, orden_venta.cliente_rif , orden_venta.cliente_direccion , orden_venta.Hora, orden_venta.Despachado, usuarios.nombre_completo, cliente.razon_social "
                        + "FROM orden_venta, usuarios, cliente "
                        + "WHERE usuarios.id = orden_venta.operadora_id "
                        + "AND orden_venta.cliente_rif = cliente.rif_codigo order by orden_venta.Hora  "
                        //+ "AND orden_venta.cliente_direccion= cliente.direccion "
                        
                        
                );
                
                while(rs.next()){
                    
                  if ( rs.getInt("despachado") == 1){  
                      
                        registros[0]=rs.getString("orden_venta.id");                    
                        registros[1]=rs.getString("cliente.razon_social");
                        registros[2]=rs.getString("orden_venta.cliente_rif");
                        registros[3]=rs.getString("orden_venta.cliente_direccion");
                        registros[4]=rs.getString("orden_venta.Hora");
                        registros[5]=rs.getString("usuarios.nombre_completo");
                        model.addRow(registros);
                        
                  }    
                  
                }
                tablaOrdenes.setModel(model);
                tablaOrdenes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en void listarCliente"+e.toString());
               }
            //codigo
            tablaOrdenes.getColumnModel().getColumn(0).setPreferredWidth(45);
            tablaOrdenes.getColumnModel().getColumn(0).setMinWidth(45);
             tablaOrdenes.getColumnModel().getColumn(0).setMaxWidth(45);
             //rif
             tablaOrdenes.getColumnModel().getColumn(2).setPreferredWidth(100);
            tablaOrdenes.getColumnModel().getColumn(2).setMinWidth(100);
             tablaOrdenes.getColumnModel().getColumn(2).setMaxWidth(100);
             //hora y fecha
             tablaOrdenes.getColumnModel().getColumn(4).setPreferredWidth(150);
            tablaOrdenes.getColumnModel().getColumn(4).setMinWidth(150);
             tablaOrdenes.getColumnModel().getColumn(4).setMaxWidth(150);
    }


 public Usuario BuscarUsuario( String usu, String contra)
 {
              conectar cc = new conectar();
                Connection cn = cc.conexion();
                try {
                    Statement st = cn.createStatement();
                    ResultSet rs = st.executeQuery("SELECT nombre_completo,aplicacion,id from usuarios Where usuario='"+usu+"' AND clave='"+contra+"'");
                    while(rs.next()){
                        String nombre = rs.getString("nombre_completo");
                        int app= rs.getInt("aplicacion");
                        int id = rs.getInt("id");
                        Usuario uuss= new Usuario(usu, nombre, contra, app, id);
                         return uuss;
                       
                    }

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("eror en buscarUsuario "+e.toString());
               }  
              
              
          return null;}
 
 public ArrayList ListarNombresClientes(){
   
            ArrayList keywords = new ArrayList<String>();
             
             
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT razon_social FROM cliente WHERE aplicacion = 1 AND activo=1");
                while(rs.next()){
                    keywords.add(rs.getString("razon_social"));
                }
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente8"+e.toString());
               }
            
            return keywords;
         } 
 
 
  
 public ArrayList ListarNombresProductos(){
   
            ArrayList keywords = new ArrayList<String>();
             
             
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT nombre_producto FROM producto");
                while(rs.next()){
                    keywords.add(rs.getString("nombre_producto"));
                }
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente9"+e.toString());
               }
            
            return keywords;
         } 
 
 
  public String BuscarCodProductos(String name){
   
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT codigo_producto FROM producto WHERE nombre_producto = '" + name + "'");
                if (rs.next()){
                   return rs.getString("codigo_producto");
                }else{
                    return null;
                }
                   
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente10"+e.toString());
               }
            
            return null;
         }
 
    public ArrayList ListarIDClientes(){
   
            ArrayList keywords = new ArrayList<String>();
             
             
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT ID FROM cliente");
                int i=0;
                while(rs.next()){
                    keywords.add(rs.getString("ID"));
                }
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente11"+e.toString());
               }
            
            return keywords;
         } 
    
    public void RestarDeAutoDemanda( JTable tablaDemanda, JTable tablaOferta, String lote, int Cantidad){
    
    String CodigoP = ObtenerProductoDeLote(lote);
    int CantidadADespachar = ObtenerCantidadAdespachar(tablaOferta, CodigoP);
    
    DefaultTableModel model = (DefaultTableModel)tablaDemanda.getModel();
    int rows = model.getRowCount(); 

    for(int i = rows - 1; i >=0; i--){
            String CodigoProducto = tablaDemanda.getModel().getValueAt(i, 0).toString();
            
            if (CodigoProducto.equals(CodigoP)){
                
                int demanda = Integer.parseInt(tablaDemanda.getModel().getValueAt(i, 1).toString());
                
                if (CantidadADespachar == demanda){
                    tablaDemanda.getModel().setValueAt( demanda-Cantidad ,i, 1);
                }
            }
    } 
       
}

public boolean ProductoOfertado(JTable tablaDemanda, JTable tablaOferta, int row){
    
    String CodigoProducto = tablaDemanda.getModel().getValueAt(row, 0).toString();
    
    DefaultTableModel model = (DefaultTableModel)tablaOferta.getModel();
    int rows = model.getRowCount(); 

    for(int i = rows - 1; i >=0; i--){
            String CodigoP = ObtenerProductoDeLote(tablaOferta.getModel().getValueAt(i, 1).toString());
            
            if (CodigoProducto.equals(CodigoP)){
                return true;
            }
    } 
    
    return false;
}    
    
    
    
    public void MarcarComoFacturado(String id){
        
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                int cant =0 ;
                
                
                //restar de la reserva       
                st.executeUpdate("UPDATE productos_reservados "
                               + "INNER JOIN ( SELECT codigo_producto, SUM(cantidad) as cantidad "
                                            + "FROM orden_x_lote as OL "
                                            + "WHERE OL.orden_id = " +id+" "
                                            + "GROUP BY codigo_producto "
                               + ") AS Result ON ( Result.codigo_producto = productos_reservados.codigo_producto ) "
                               + "SET productos_reservados.cantidad_reservada = productos_reservados.cantidad_reservada - Result.cantidad "

                );        
      
                //restar de la tabla de lotes          
                st.executeUpdate("UPDATE lote_producto "
                               + "INNER JOIN orden_x_lote ON ( Orden_x_lote.correlativo_lote =  lote_producto.correlativo "
                               + "AND Orden_x_lote.Orden_id = "+ id + " )"
                               + "SET  lote_producto.cantidad_x_lote =  lote_producto.cantidad_x_lote - orden_x_lote.cantidad "

                ); 
                
                st.executeUpdate("UPDATE orden_venta SET despachado = 1 WHERE id = " + id );

            } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
            }
            catch( java.lang.NumberFormatException e) {
                   System.out.println("error producido en void listarCliente12"+e.toString());
            }
    }
 
public void InsertarDemanda( JTable tabla){
                         
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            String FechaActual;
           
            try {
                
                Calendar cal = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                FechaActual = sdf.format(cal.getTime());
                
                Statement st = cn.createStatement();

                for (int count = 0; count < ((DefaultTableModel)tabla.getModel()).getRowCount(); count++){
                   
                   String producto = ((DefaultTableModel)tabla.getModel()).getValueAt(count, 0).toString(); //cod
                   String cantidad = ((DefaultTableModel)tabla.getModel()).getValueAt(count, 1).toString(); //cant 
                   ResultSet rs = st.executeQuery("SELECT * FROM estadisticas_demanda_productos WHERE codigo_producto = '"+producto+"' AND fecha = '"+FechaActual+"'");
                    System.out.println("SELECT * FROM estadisticas_demanda_productos WHERE codigo_producto = '"+producto+"' AND fecha = "+FechaActual);
                  
                   if ( !rs.next() ){
                       
                        PreparedStatement MSQL_statement = cn.prepareStatement("INSERT INTO estadisticas_demanda_productos ( Codigo_producto , cantidad , fecha ) VALUES (?,?,?)");

                        MSQL_statement.setString(1, producto);
                        MSQL_statement.setString(2, cantidad);
                        MSQL_statement.setString(3, FechaActual);
                        
                        System.out.println(MSQL_statement);
                        MSQL_statement.executeUpdate();
              
                   }
                   else {
                         System.out.println("updateando: "+ producto);
                        st.executeUpdate("UPDATE estadisticas_demanda_productos SET cantidad = cantidad + "+cantidad+" WHERE Codigo_producto = '"+producto +"' AND fecha = '"+FechaActual+"'");
                        
                   }
                   
                }
                
                    /////LIMPIAR TABLA DE DESPACHO
     
                    DefaultTableModel model = (DefaultTableModel)tabla.getModel();
                    
                     TableCellEditor editor = tabla.getCellEditor();
                     if ( editor != null) editor.stopCellEditing();
                     
                    int rows = model.getRowCount(); 
                    for(int i = rows - 1; i >=0; i--){          
                        model.removeRow(i);
                    }
     
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente13"+e.toString());
               }
            
          
} 




public void CrearRegistroLlamada(String usuario, String riff, String direccion, String idCliente, int exitosa, Calendar cal, String Monto, long tiempo){
                         
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            String FechaActual;
            String HoraActual;
           
            try {

                SimpleDateFormat sdfFecha = new SimpleDateFormat("dd-MM-yyyy");
                SimpleDateFormat sdfHora = new SimpleDateFormat("HH:mm:ss");
                
                FechaActual = sdfFecha.format(cal.getTime());
                HoraActual = sdfHora.format(cal.getTime());
                
                System.out.println(FechaActual + " " + HoraActual);
                       
                PreparedStatement MSQL_statement = cn.prepareStatement(
                        "INSERT INTO registro_llamadas ( usuario , id_cliente , rif_codigo, direccion, fecha_llamada, hora_llamada, exitosa, monto_venta_contado, duracion ) VALUES (?,?,?,?,?,?,?,?,?)");

                MSQL_statement.setString(1, usuario);
                MSQL_statement.setString(2, idCliente);
                MSQL_statement.setString(3, riff);
                MSQL_statement.setString(4, direccion);
                MSQL_statement.setString(5, FechaActual);
                MSQL_statement.setString(6, HoraActual);
                MSQL_statement.setInt   (7, exitosa);
                MSQL_statement.setInt   (8, Integer.parseInt(Monto));
                MSQL_statement.setInt   (9, (int) tiempo);
                        
                System.out.println(MSQL_statement);
                MSQL_statement.executeUpdate();
     
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente14"+e.toString());
               }
            
          
} 


public void ActualizarUltimaLLmadas(String rif, String direccion, Calendar cal){
                         
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            String FechaActual;
           
            try {

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                FechaActual = sdf.format(cal.getTime());
                java.sql.Timestamp FA = new java.sql.Timestamp(sdf.parse(FechaActual).getTime());
                       
                PreparedStatement  MSQL_statement = cn.prepareStatement("DELETE FROM ultimas_llamadas WHERE rif_codigo  = ? AND direccion = ? ");
                MSQL_statement.setString(1, rif);
                MSQL_statement.setString(2, direccion);
                MSQL_statement.executeUpdate();
                
                MSQL_statement = cn.prepareStatement(
                        "INSERT INTO ultimas_llamadas ( rif_codigo , direccion, Ultima_Llamada ) VALUES (?,?,?)");

                MSQL_statement.setString(1, rif);
                MSQL_statement.setString(2, direccion);
                MSQL_statement.setTimestamp(3, FA);
         
                        
                System.out.println(MSQL_statement);
                MSQL_statement.executeUpdate();
     
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente15"+e.toString());
               }
            
          
} 

public void ReservarProducto(String CodigoProducto, int Cantidad){
                         
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                
                Statement st = cn.createStatement();

                    ResultSet rs = st.executeQuery("SELECT * FROM productos_reservados WHERE codigo_producto = '"+CodigoProducto+"' ");
                  
                   if ( !rs.next() ){
                       
                        PreparedStatement MSQL_statement = cn.prepareStatement("INSERT INTO productos_reservados ( Codigo_producto , cantidad_reservada ) VALUES (?,?)");

                        MSQL_statement.setString(1, CodigoProducto);
                        MSQL_statement.setInt(2, Cantidad);
   
                        System.out.println(MSQL_statement);
                        MSQL_statement.executeUpdate();
              
                   }
                   else {

                        st.executeUpdate("UPDATE productos_reservados SET cantidad_reservada = cantidad_reservada + "+Cantidad+" WHERE Codigo_producto = '"+CodigoProducto+"' ");
                        
                   }
                   
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente16"+e.toString());
               }
            
            
          
} 

public void InsertarLotexOrden(int IDorden, String Producto, Reserva R, int cantidad , String operadora ){
                         
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                       
                PreparedStatement MSQL_statement = cn.prepareStatement(
                        "INSERT INTO orden_x_lote ( correlativo_lote, Orden_id , codigo_producto ,lote_producto , cantidad , operadora ) VALUES (?,?,?,?,?)");
                
                MSQL_statement.setString(1, R.getCorrelativo());
                MSQL_statement.setInt(2, IDorden);
                MSQL_statement.setString(3, Producto );
                MSQL_statement.setString(4, R.getLote());
                MSQL_statement.setInt(5, cantidad);
                MSQL_statement.setString(6, operadora);

                        
                System.out.println(MSQL_statement);
                MSQL_statement.executeUpdate();
     
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente17"+e.toString());
               }
            
          
} 

public void EliminarLoteDeReserva(String CodigoLote, int Cantidad){
                         
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                
                Statement st = cn.createStatement();
                
                st.executeUpdate("UPDATE lotes_reservados SET cantidad_reservada = cantidad_reservada - "+Cantidad+" WHERE correlativo_lote = '"+CodigoLote+"'");
      
                   
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente18"+e.toString());
               }
      
} 



public Reserva[] ObtenerListaDeLotes2(String IDproducto ) {
    
    ArrayList Lista = new ArrayList<Reserva>();
            
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            System.out.println("l2\n");  
            
            try {
                Statement st = cn.createStatement();
                
               ResultSet rs = st.executeQuery(                        
                        "SELECT R.codigo_lote as codigo_lote, R.lote as lote, R.fecha_ingreso, (LP2.cantidad - SUM(R.cantidad )) as cantidadTotal\n" +
                        "FROM \n" +
                        "(SELECT LP.correlativo as codigo_lote, LP.lote_producto as lote, LP.fecha_ingreso, OL.cantidad as cantidad \n" +
                        "FROM lote_producto as LP, orden_x_lote as OL, orden_venta as OV  \n" +
                        "WHERE OV.despachado = 0 \n" +
                        "AND LP.codigo_producto = '" + IDproducto+"' "+
                        "AND OL.orden_id = OV.id \n" +
                        "AND OL.correlativo_lote = LP.correlativo \n" +

                        "UNION ALL \n" +

                        "SELECT LP.correlativo as codigo_lote, LP.lote_producto as lote, LP.fecha_ingreso, LR.cantidad_reservada as cantidad \n" +
                        "FROM lote_producto as LP, lotes_reservados as LR  \n" +
                        "WHERE LP.codigo_producto = '"  + IDproducto+"' "+
                        "AND LR.correlativo_lote = LP.correlativo ) as R,\n" +

                        "(SELECT LP.correlativo as codigo_lote, LP.cantidad_x_lote as cantidad \n" +
                        " FROM Lote_producto as LP\n" +
                        " WHERE LP.codigo_producto = '"  + IDproducto+"' "+
                        " ) as LP2 \n" +
                                
                        "WHERE R.codigo_lote = LP2.codigo_lote\n" +
                        "GROUP BY   R.codigo_lote, R.lote, R.fecha_ingreso\n" +

                        "UNION ALL\n" +
                                
                        "SELECT LP.correlativo as codigo_lote, LP.lote_producto as lote, LP.fecha_ingreso, LP.cantidad_x_lote as cantidad \n" +
                        "FROM lote_producto as LP LEFT JOIN orden_x_lote AS OL ON OL.correlativo_lote = LP.correlativo \n" +
                        "                         LEFT JOIN lotes_reservados AS LR ON LR.correlativo_lote = LP.correlativo\n" +
                        "WHERE  OL.correlativo_lote IS NULL\n" +
                        "AND LR.correlativo_lote IS NULL \n" +
                        "AND LP.codigo_producto = '"  + IDproducto+"' "
                        
                ); 
                
               
              
            
               
                while(rs.next()){
                   
                        Lista.add( new Reserva( rs.getString("codigo_lote"), rs.getInt("cantidadTotal"), rs.getString("lote"), rs.getString("fecha_ingreso") ) );
   
                }
                
                Reserva[] ListaProductos = new Reserva[Lista.size()];
                
                ListaProductos = (Reserva[]) Lista.toArray( ListaProductos);
                
                Arrays.sort(ListaProductos);    
               
		for(Reserva temp: ListaProductos){
		   System.out.println("lote: " + temp.getCorrelativo() + " - " + temp.getFecha() + " - cantidad: "+temp.getCantidad());
		}
                
                return ListaProductos;
                
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                    return null;
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en void listarCliente19"+e.toString());
                   return null;
               }
    
    
}

public void ReservarLote(String CodigoLote, int Cantidad){
                         
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                
                Statement st = cn.createStatement();

                    ResultSet rs = st.executeQuery("SELECT * FROM lotes_reservados WHERE correlativo_lote = '"+CodigoLote+"'");
                  
                   if ( !rs.next() ){
                        
                        rs = st.executeQuery("SELECT codigo_producto FROM lote_producto WHERE correlativo = '"+CodigoLote+"'");
                        rs.next();
                        String CodigoProducto = rs.getString("codigo_producto");
                       
                        PreparedStatement MSQL_statement = cn.prepareStatement("INSERT INTO  lotes_reservados  ( Codigo_producto , correlativo_lote, cantidad_reservada ) VALUES (?,?,?)");

                        MSQL_statement.setString(1, CodigoProducto);
                        MSQL_statement.setString(2, CodigoLote);
                        MSQL_statement.setInt(3, Cantidad);
   
                        System.out.println(MSQL_statement);
                        MSQL_statement.executeUpdate();
              
                   }
                   else {

                        st.executeUpdate("UPDATE lotes_reservados SET cantidad_reservada = cantidad_reservada + "+Cantidad+" WHERE Correlativo_lote = '"+CodigoLote+"' ");
                        
                   }
                   
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente20"+e.toString());
               }
            
            
          
} 


public int CrearOrdenVenta( int usr , String rif, String direccion){
    
            int ID=0;
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            String HoraActual;
           
            try {
                
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.MINUTE, 30);
                HoraActual = sdf.format(cal.getTime());
                java.sql.Timestamp HA = new java.sql.Timestamp(sdf.parse(HoraActual).getTime());
                
                
                PreparedStatement MSQL_statement = cn.prepareStatement(
                        "INSERT INTO orden_venta ( hora , operadora_id , cliente_rif, cliente_direccion, despachado ) VALUES (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);

                MSQL_statement.setTimestamp(1, HA );
                MSQL_statement.setInt(2, usr);
                MSQL_statement.setString(3, rif);
                MSQL_statement.setString(4, direccion);
                MSQL_statement.setInt(5, 0);

                        
                MSQL_statement.executeUpdate();
     
                ResultSet rs = MSQL_statement.getGeneratedKeys();
                rs.next();
                ID = rs.getInt(1);
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente21"+e.toString());
               }
          
          return ID;
}

public int ObtenerCantidadProducto(String Producto){
    
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                
                Statement st = cn.createStatement();
                
                ResultSet rs = st.executeQuery("SELECT * FROM productos_reservados WHERE codigo_producto = '"+Producto+"' ");
                
                if (!rs.next()){
                rs = st.executeQuery("SELECT codigo_producto, SUM(cantidad_x_lote) as Cant FROM lote_producto WHERE codigo_producto = '"+Producto+"' GROUP BY codigo_producto");
                }
                else{
                rs = st.executeQuery( "SELECT lp.codigo_producto, (SUM(lp.cantidad_x_lote)- R.cantidad_reservada) as Cant FROM lote_producto as lp, productos_reservados as R WHERE lp.codigo_producto = '"+ Producto+"' AND lp.codigo_producto = R.Codigo_Producto   GROUP BY lp.codigo_producto");
               }
                
                rs.next();
                return rs.getInt("Cant");
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente22"+e.toString());
               }
            
            
    
    return 0;
}

public int ObtenerPrecioLote(String Lote){
    
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                
                Statement st = cn.createStatement();

                ResultSet rs = st.executeQuery("SELECT precio_x_lote FROM lote_producto WHERE correlativo = '"+Lote+"'");
                
                rs.next();
                return rs.getInt("precio_x_lote");
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void ObtenerPrecio"+e.toString());
               }
            
            
    
    return 0;
}

public String ObtenerProductoDeLote(String Lote){
    
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                
                Statement st = cn.createStatement();

                ResultSet rs = st.executeQuery("SELECT codigo_producto FROM lote_producto WHERE correlativo = '"+Lote+"'");
                
                rs.next();
                return rs.getString("codigo_producto");
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void ObtenerPrecio"+e.toString());
               }
            
            
    
    return " ";
}

public String ObtenerProductoDeCodigo(String Codigo){
    
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                
                Statement st = cn.createStatement();

                ResultSet rs = st.executeQuery("SELECT nombre_producto FROM producto WHERE codigo_producto = '"+Codigo+"'");
                
                rs.next();
                return rs.getString("nombre_producto");
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void ObtenerPrecio"+e.toString());
               }
            
            
    
    return " ";
}

public ArrayList SeleccionarLotes(Reserva[] ArrayLotes, int cant ) {
    
     
            ArrayList Lista = new ArrayList<Reserva>();
            int i=0;
            
            while( cant > 0){

                    if( ArrayLotes[i].getCantidad() <= cant ){
                        
                        if (ArrayLotes[i].getCantidad() != 0){
                            cant = cant - ArrayLotes[i].getCantidad();
                            Lista.add(ArrayLotes[i]);
                        }

                    }
                    else{
                        Reserva R = new Reserva(ArrayLotes[i].getCorrelativo(), cant, ArrayLotes[i].getLote(), ArrayLotes[i].getFecha());
                        Lista.add(R);
                        cant = 0;

                    }


                 i++;   
                }
            
            return Lista;
}


public int Despachar2(int IDorden, String operadora,  JTable tabla){
    
    int cant = 0;
    
     //suponiendo que la tabla contiene IDproducto - IDlote - Cantidad - Precio
    
     for (int count = 0; count < ((DefaultTableModel)tabla.getModel()).getRowCount(); count++){
         
           
            
            String Lote = ((DefaultTableModel)tabla.getModel()).getValueAt(count, 1).toString(); 
            String Producto = this.ObtenerProductoDeLote(Lote);
            
           
         
            try{

               cant = Integer.parseInt(((DefaultTableModel)tabla.getModel()).getValueAt(count, 2).toString());

            }catch(java.lang.NumberFormatException e){
               if ( ((DefaultTableModel)tabla.getModel()).getValueAt(count, 1).toString().equals("") )  break;
               else if ( ((DefaultTableModel)tabla.getModel()).getValueAt(count, 1).toString().equals(" ") ) break;
               else { 
                    showMessageDialog(tabla, "El producto "+Producto+" no pudo ser procesado por un error en la cantidad.\n por favor verifique que la cantidad especificada solo contiene numeros.");
                    break;
               }
            }
  
         if( !Producto.equals("")){
                    new Funcion().EliminarLoteDeReserva( Lote , cant);
                    InsertarLotexOrden( IDorden, Producto,  new Reserva("123", Lote) , cant , operadora );
        }
      
   
    }
     
    /////LIMPIAR TABLA DE DESPACHO
     
    DefaultTableModel model = (DefaultTableModel)tabla.getModel();
    int rows = model.getRowCount(); 
    for(int i = rows - 1; i >=0; i--){          
        model.removeRow(i);
    }
     
     return cant;
} 

public void limpiarTabla( JTable tabla){
    DefaultTableModel model = (DefaultTableModel)tabla.getModel();
                int rows = model.getRowCount(); 
                for(int i = rows - 1; i >=0; i--){
                    model.removeRow(i);
                }
}

public void EliminarDeReserva(String CodigoLote, int Cantidad){
                         
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                
                Statement st = cn.createStatement();
               
                ResultSet rs = st.executeQuery("SELECT codigo_producto FROM lote_producto WHERE correlativo = '"+CodigoLote+"'");
                System.out.println(rs);
                rs.next();
                
                st.executeUpdate("UPDATE productos_reservados SET cantidad_reservada = cantidad_reservada - "+Cantidad+" WHERE Codigo_producto = '"+rs.getString("codigo_producto")+"' ");
      
                   
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente23"+e.toString());
               }
      
} 



public void AddListaATabla( JTable tabla, String Producto, ArrayList<Reserva> a){
    
        String [] registros = new String [5];
        
    for (int i = 0; i < a.size(); i++) {
                                         
                        conectar cc = new conectar();
                        Connection cn = cc.conexion(); 
                        try {
                            Statement st = cn.createStatement();
                            ResultSet rs = st.executeQuery("SELECT Precio_x_lote FROM lote_producto WHERE correlativo = '"+a.get(i).getCorrelativo()+"'");
                            
                            
                            registros[0]= Producto;
                            registros[1]=a.get(i).getCorrelativo();
                            registros[2]=Integer.toString(a.get(i).getCantidad());
                            registros[3]=rs.getString("precio_x_lote");
                            registros[4]=Integer.toString(rs.getInt("precio_x_lote")*a.get(i).getCantidad());

                            ((DefaultTableModel)tabla.getModel()).addRow(registros); 
                            
                            
                        }     
                        catch( Exception e){
                               System.out.println("error producido en void listarCliente24"+e.toString());
                        }
                    
    }
  
 }

 public void ActualizarMontoTotal(JLabel label, JTable tabla){
     
      int monto = 0;
     
      if ( ((DefaultTableModel)tabla.getModel()).getRowCount() == 0 ){
          label.setText("Monto total: 0 Bs.");
          return;
      }
      
      for (int count = 0; count < ((DefaultTableModel)tabla.getModel()).getRowCount(); count++){
          
          int PrecioProductoi = Integer.parseInt(((DefaultTableModel)tabla.getModel()).getValueAt(count, 4).toString());
          monto = monto + PrecioProductoi;
          
      }
      
      label.setText("Monto total: "+monto+" Bs.");
     
 }

   public void ListarUsuario(JList jListUsu) throws SQLException{
        conectar cc = new conectar();
        Connection cn = cc.conexion();
        DefaultListModel dlm= new DefaultListModel();
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery("SELECT  concat_ws(' ',usuario,nombre_completo) as nomb FROM usuarios\n" +
"where nombre_completo <> 'super usuario' AND activo = 1;");
               while(rs.next()){
                   String nom=rs.getString("nomb");
           dlm.addElement(nom);
               }
               jListUsu.setModel(dlm);
             
            }
         catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,ex);
        }
}
   
public boolean DisponibleUsuario(String usuario)
{
    System.out.println("usuario disponible:"+usuario);
    conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT \n" +
                                               "case when  usuarios.usuario='"+usuario+"'   then 1 else 0 END as verda\n" +
                                               "from usuarios");
                while(rs.next()){
                    System.out.println("true");
                   int num=Integer.parseInt(rs.getString("verda"));
                    System.out.println("num "+num);
                   if(num==1)
                       return true;
                    }
                
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en boolean disponibleUsuario "+e.toString());
               }
    
return false;}

public void LlenarOperadorasCombo(JComboBox combo1 ,JComboBox combo2){
    
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            try {
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT  id, nombre_completo\n" + 
                                               "from usuarios "
                                             + "WHERE aplicacion = 1 AND activo = 1");
                while(rs.next()){
                    combo1.addItem(rs.getString("id")+"- "+rs.getString("nombre_completo"));
                    combo2.addItem(rs.getString("id")+"- "+rs.getString("nombre_completo"));
                }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en boolean disponibleUsuario "+e.toString());
               }
    
    
}

public void AsignarClientesDeOperadora(JTable tabla, JComboBox combo1, JComboBox combo2){
    
    int row = tabla.getSelectedRow();
    
    String rif=tabla.getValueAt(row, 0).toString();
    String direccion = tabla.getValueAt(row,2).toString();
    String Operadora1 = combo1.getSelectedItem().toString();
    String Operadora2 = combo2.getSelectedItem().toString();
    
    conectar cc = new conectar();
    Connection cn = cc.conexion();
           
    try {
        
           PreparedStatement MSQL_statement;
           
           if ( Operadora1.equals("Sin Asignar") ){
               
                   MSQL_statement = cn.prepareStatement("INSERT INTO operadora_x_cliente ( operadora, rif_codigo, direccion ) VALUES (?,?,?)");
                   MSQL_statement.setString(1, Operadora2.substring(0, Operadora2.indexOf("- ")));
                   MSQL_statement.setString(2, rif);
                   MSQL_statement.setString(3, direccion);
                   
           }else{
              if ( Operadora2.equals("Sin Asignar") ){
                   MSQL_statement = cn.prepareStatement("DELETE FROM operadora_x_cliente WHERE direccion = '"+direccion+"' AND rif_codigo = '"+rif+"'" );
              }
              else{
                   MSQL_statement = cn.prepareStatement("UPDATE operadora_x_cliente SET operadora = "+Operadora2.substring(0, Operadora2.indexOf("- "))+" WHERE direccion = '"+direccion+"' AND rif_codigo = '"+rif+"'");
              }
             
           }    
        
                System.out.println(MSQL_statement);
                MSQL_statement.executeUpdate();
                DefaultTableModel model = (DefaultTableModel)tabla.getModel();
                model.removeRow(row);
     
    }     
    catch( Exception e){
                   System.out.println("error producido en void listarCliente25"+e.toString());
    }
    
    
    
    
}

public void ListarClientesDeOperadora(JTable tabla, JComboBox combo){
    
            String Operadora = combo.getSelectedItem().toString();
            
            DefaultTableModel model;
            String [] titulos={"rif", "cliente","direccion"};
            String [] registros = new String [3];
            model= new DefaultTableModel(null,titulos){
                 @Override
                 public boolean isCellEditable(int row, int column) {
                     return false;
                 }
             };

            conectar cc = new conectar();
            Connection cn = cc.conexion();
            
            try {

                            ResultSet rs;

                            if (  Operadora.equals("Sin Asignar")){
                                Statement st = cn.createStatement();
                                 rs = st.executeQuery("SELECT c.rif_codigo, c.razon_social, c.direccion\n" +
                                                      "from cliente as c left join operadora_x_cliente as oc on (c.rif_codigo = oc.rif_codigo AND c.direccion = oc.direccion)\n" +
                                                      "WHERE oc.rif_codigo IS NULL\n" +
                                                      "AND oc.direccion IS NULL");
                            }else{
                                Statement st = cn.createStatement();
                                 rs = st.executeQuery("SELECT c.rif_codigo, c.razon_social, c.direccion\n" +
                                                        "from cliente as c, operadora_x_cliente as oc\n" +
                                                        "WHERE c.rif_codigo = oc.rif_codigo \n" +
                                                        "AND c.direccion = oc.direccion\n" +
                                                        "AND oc.operadora = " + Operadora.substring(0, Operadora.indexOf("- ")));
                            }
                            while(rs.next()){
                             registros[0]= rs.getString("c.rif_codigo");
                             registros[1]=rs.getString("c.razon_social");
                             registros[2]=rs.getString("c.direccion");
                             model.addRow(registros);
                            }
                            
                            tabla.setModel(model);
                            tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(null,ex);
                        }
            catch( java.lang.NumberFormatException e)
                       {
                           System.out.println("error producido en boolean disponibleUsuario "+e.toString());
                       }
            
    
}

public int NumeroDepartamento(JComboBox combo)
{
     int depa=combo.getSelectedIndex();
       switch(depa){
               case 0: return 1;
               case 1: return 2;
               case 2: return 4;
                   }
       return 0;
}
   
public void comprobarUsuario(String nombre,String Usuario,String clave1,int departamento)
{System.out.println("entro a comprobarUsuario");
     
if( DisponibleUsuario(Usuario)!=true)
     {
         System.out.println("entro al if de comprobaru");
       conectar cc = new conectar();
            Connection cn = cc.conexion();
             try {
PreparedStatement MSQL_statement = cn.prepareStatement(
  "INSERT INTO usuarios ( usuario , nombre_completo , clave, aplicacion ) VALUES (?,?,?,?)");

                MSQL_statement.setString(1, Usuario);
                MSQL_statement.setString(2, nombre);
                MSQL_statement.setString(3, clave1);
                MSQL_statement.setInt(4, departamento);
                 System.out.println(MSQL_statement);
                MSQL_statement.executeUpdate();
                JOptionPane.showMessageDialog(null,"El usuario ha sido creado satisfactoriamente");
            }     
            catch( Exception e){
                   System.out.println("error producido en void comprobar usuario"+e.toString());
               }
     }
else
     JOptionPane.showMessageDialog(null,"El usuario ya existe");
    
//    return false;
}


public void deshabilitarUsuario(String usuario)
{
    
    conectar cc = new conectar();
            Connection cn = cc.conexion();
            try { 
                Statement st = cn.createStatement();
                st.executeUpdate("UPDATE `usuarios` SET `activo`='0' WHERE concat_ws(' ',usuario,nombre_completo)='"+usuario+"';");
                JOptionPane.showMessageDialog(null,"El usuario ha sido deshabilitado");
                
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println("error producido en void deshabilitarUsuario "+e.toString());
               }
    }


public boolean ProductoDuplicado( String CodigoProducto, JTable tabla){
    
    for (int count = 0; count < ((DefaultTableModel)tabla.getModel()).getRowCount(); count++){
       
        if (tabla.getModel().getValueAt(count, 0).toString().equals(CodigoProducto)){
            return true;
        }
    }
    return false;
}
   

public void DeshabilitarEnterEnTabla(JTable table) {
    
        table.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "Enter");
            table.getActionMap().put("Enter", new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent ae) {
                    //hacer nada
                }
            });
}

public void LlenarEstadisticasOperadoras( JTable tabla){
    
     DefaultTableModel model;
     
     String [] titulos={"ID", "operadora","Llamadas","no exitosas","tasa exito", "tiempo total", "tiempo no exitoso", "unidades vendidas", "monto total", "Cartera Cumplida"};
     String [] registros = new String [10];
     model= new DefaultTableModel(null,titulos){
                 @Override
                 public boolean isCellEditable(int row, int column) {
                     return false;
                 }
     };
    
            conectar cc = new conectar();
            Connection cn = cc.conexion();
            
            try { 
                float[][] estadisticas = new float[255][8];
                estadisticas = Estadisticas();
                
                Statement st = cn.createStatement();
                ResultSet rs = st.executeQuery("SELECT a.usuario,b.nombre_completo FROM registro_llamadas a, usuarios b WHERE a.usuario = b.id AND b.aplicacion = 1 AND b.activo=1 GROUP BY usuario");
              
                while(rs.next()){
                    
                    float Llamadas = estadisticas[Integer.valueOf(rs.getString("usuario"))][1];
                    float NoExitosas = estadisticas[Integer.valueOf(rs.getString("usuario"))][4];
                    
                    
                    registros[0]= rs.getString("a.usuario");
                    registros[1]= rs.getString("b.nombre_completo");
                    registros[2]=String.valueOf((int)Llamadas);
                    registros[3]=String.valueOf((int)NoExitosas);
                    registros[4]=String.format("%.2f",((1-(NoExitosas/Llamadas))*100))+"%";
                    registros[5]=String.format("%.2f",estadisticas[Integer.valueOf(rs.getString("usuario"))][0]/60)+" m";
                    registros[6]=String.format("%.2f",estadisticas[Integer.valueOf(rs.getString("usuario"))][3]/60)+" m";
                    registros[7]=String.valueOf((int)estadisticas[Integer.valueOf(rs.getString("usuario"))][6]);
                    registros[8]=String.valueOf((int)estadisticas[Integer.valueOf(rs.getString("usuario"))][7])+"Bs.";
                    registros[9]=String.format("%.2f",(estadisticas[Integer.valueOf(rs.getString("usuario"))][2]/estadisticas[Integer.valueOf(rs.getString("usuario"))][5])*100)+"%";
                    model.addRow(registros);
                }
                
            } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
            }
            catch (IOException ex) {
                    JOptionPane.showMessageDialog(null,ex);
            }
            catch( java.lang.NumberFormatException e)
            {
                   System.out.println("error producido en void deshabilitarUsuario "+e.toString());
            }
     
    
     tabla.setModel(model);
     tabla.getColumnModel().getColumn(0).setPreferredWidth(30);           
     tabla.getColumnModel().getColumn(0).setMinWidth(30);
     tabla.getColumnModel().getColumn(0).setMaxWidth(30);
}

public float[][] Estadisticas() throws IOException {
    
    int max_users = 255;
    int i = 0;
    
    conectar cc = new conectar();
    float[][] estadisticas;
    String [] users = new String [max_users];
    
    Calendar c = Calendar.getInstance();
        c.setFirstDayOfWeek(Calendar.MONDAY);

        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        String monday = sdf.format(c.getTime());
    
    // Arreglo de entero - Indice 1: operadora - Indice 2: Estadistica
    
    
            Connection cn = cc.conexion();
            try {
                
                Statement st = cn.createStatement();
                ResultSet rs;
                
                
                // Obtener lista de usuarios e ingresarla al informe en excel
                rs = st.executeQuery("SELECT a.usuario,b.nombre_completo FROM registro_llamadas a, usuarios b WHERE a.usuario = b.id AND b.aplicacion = 1 AND b.activo=1 GROUP BY usuario");
                while(rs.next()){
                    exp.ingresarUsuarios(rs.getString("nombre_completo"));
                }
                
                
                 // Estadistica 0 - Tiempo total de operaciones (en minutos)
                rs = st.executeQuery("SELECT usuario, sum(duracion) AS total FROM registro_llamadas WHERE str_to_date(fecha_llamada,'%d-%m-%Y') >= '"+monday+"' GROUP BY usuario");
                while(rs.next()){
                    est[Integer.valueOf(rs.getString("usuario"))][0] = rs.getInt("total");
                }
                 
                 // Estadistica 1 - Numero de operaciones
                rs = st.executeQuery("SELECT usuario, count(usuario) AS cuenta FROM registro_llamadas where str_to_date(fecha_llamada,'%d-%m-%Y') >= '"+monday+"' GROUP BY usuario");
                while(rs.next()){
                    est[Integer.valueOf(rs.getString("usuario"))][1] = rs.getInt("cuenta");
                }
                
                // Estadistica 2 - Promedio de tiempo por operacion (en minutos)
                rs = st.executeQuery("SELECT usuario, avg(duracion) AS promedio FROM registro_llamadas where str_to_date(fecha_llamada,'%d-%m-%Y') >= '"+monday+"' GROUP BY usuario ORDER BY usuario");
                while(rs.next()){
                    est[Integer.valueOf(rs.getString("usuario"))][2] = rs.getFloat("promedio");
                }
                
                
                // Estadistica 3 - Tiempo total de operaciones no concretadas (en minutos)
                rs = st.executeQuery("SELECT usuario, sum(duracion) AS total FROM registro_llamadas WHERE exitosa = 0 and str_to_date(fecha_llamada,'%d-%m-%Y') >= '"+monday+"' GROUP BY usuario");
                while(rs.next()){
                    est[Integer.valueOf(rs.getString("usuario"))][3] = rs.getInt("total");
                }
                
               
                // Estadistica 4 - Numero de operaciones no concretadas
                rs = st.executeQuery("SELECT usuario, count(usuario) AS total FROM registro_llamadas WHERE exitosa = 0 and str_to_date(fecha_llamada,'%d-%m-%Y') >= '"+monday+"' GROUP BY usuario");
                while(rs.next()){

                    est[Integer.valueOf(rs.getString("usuario"))][4] = rs.getInt("total");
                }
                
                
                // Estadistica 5 - porcentaje de cartera de clientes
                rs =  st.executeQuery( //Clientes totales                  
                      "SELECT operadora, count(rif_codigo) AS clientes FROM operadora_x_cliente GROUP BY operadora");
                while(rs.next()){
                    est[Integer.valueOf(rs.getString("operadora"))][5] = rs.getInt("clientes");
                }
                rs =  st.executeQuery(  //Clientes llamados en la semana                 
                      "SELECT s1.usuario AS operadora, count(DISTINCT s1.rif_codigo) AS llamados FROM registro_llamadas s1 WHERE str_to_date(s1.fecha_llamada,'%d-%m-%Y') >= '"+monday+"' AND s1.rif_codigo IN (SELECT rif_codigo from operadora_x_cliente where s1.usuario = operadora)  GROUP BY operadora");
                while(rs.next()){
                    float llamadas = rs.getInt("llamados");
                    float clientes;
                    
                    clientes = Math.round(est[Integer.valueOf(rs.getString("operadora"))][5]);
                    System.out.printf ("clientes: " + clientes + "  ");
                    System.out.printf ("llamadas: " + llamadas + "  ");
                    if (llamadas <= clientes && clientes != 0){
                        System.out.printf (" Calculando cartera" + llamadas/clientes * 100 + "   ");
                        est[Integer.valueOf(rs.getString("operadora"))][5] = (((float)llamadas/clientes) * 100);
                        System.out.printf (" Salida : " + est[Integer.valueOf(rs.getString("operadora"))][5] + "  " );
                    }
                    else {
                        System.out.printf (" No hay cartera");
                        est[Integer.valueOf(rs.getString("operadora"))][5] = 0;
                    }
                }

               
               // Estadistica 6 - Numero de unidades vendidas
                rs = st.executeQuery("SELECT ol.operadora, sum(ol.cantidad) AS total FROM orden_x_lote AS ol, orden_venta as ov WHERE ol.orden_id = ov.id and ov.hora >= '"+monday+" 00:00:00' GROUP BY operadora");
                while(rs.next()){
                    est[Integer.valueOf(rs.getString("operadora"))][6] = rs.getInt("total");
                }
                
                
                // Estadistica 7 - Monto de operacion
                rs = st.executeQuery("SELECT usuario, sum(monto_venta_contado) AS total FROM registro_llamadas WHERE str_to_date(fecha_llamada,'%d-%m-%Y') >= '"+monday+"'GROUP BY usuario");
                while(rs.next()){
                    est[Integer.valueOf(rs.getString("usuario"))][7] = rs.getInt("total");
                }
                
                exp.ingresarEstadisticas(est);
                return est;
                
                
                
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,ex);
                }
               catch( java.lang.NumberFormatException e)
               {
                   System.out.println(" error producido en int[] Estadisticas "+e.toString());
               }
            
            return null;
    }

/*
 public int ContarNoLlamados(int usuario){
     conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                Statement st = cn.createStatement();
                ResultSet rs;
                
                Calendar c = Calendar.getInstance();
                c.setFirstDayOfWeek(Calendar.MONDAY);

                c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                c.set(Calendar.HOUR_OF_DAY, 0);
                c.set(Calendar.MINUTE, 0);
                c.set(Calendar.SECOND, 0);
                c.set(Calendar.MILLISECOND, 0);
                
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                
                String monday = sdf.format(c.getTime());
 
              rs =  st.executeQuery(                   
                      "SELECT p2.nombre_completo, count(p1.rif_codigo) as total , p1.direccion "
                      +    "FROM operadora_x_cliente p1, usuarios p2 "
                      +    "where p1.rif_codigo not in "
                              + "(select rif_codigo from registro_llamadas WHERE usuario = " + usuario + " and str_to_date(fecha_llamada,'%d-%m-%Y') >= '"+monday+"' ) "
                      +    "and p1.operadora = " + usuario + " " 
                      +    "and p2.id = p1.operadora "
                      );
              rs.next();
              return  rs.getInt("total");
                
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente26"+e.toString());
                   return 0;
               }
 }
 */
 
 public void ListarCuota(int usuario, JTable tabla){
   
     
      DefaultTableModel model;
      String [] titulos={"Rif", "Direccion"};
      String [] registros = new String [2];
      model= new DefaultTableModel(null,titulos){
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
      };
            // hay que transformar esto para la gui que utilizes,
            // El sql saca el nombre completo, rif y direccion del clientes que
            // tal operadora no ha llamado
             
             System.out.println(usuario);
             
            conectar cc = new conectar();
            Connection cn = cc.conexion();
           
            try {
                Statement st = cn.createStatement();
                ResultSet rs;
                
                Calendar c = Calendar.getInstance();
                c.setFirstDayOfWeek(Calendar.MONDAY);

                c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                c.set(Calendar.HOUR_OF_DAY, 0);
                c.set(Calendar.MINUTE, 0);
                c.set(Calendar.SECOND, 0);
                c.set(Calendar.MILLISECOND, 0);
                
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                
                String monday = sdf.format(c.getTime());
 
              rs =  st.executeQuery(                   
                      "SELECT p2.nombre_completo, p1.rif_codigo, p1.direccion "
                      +    "FROM operadora_x_cliente p1, usuarios p2 "
                      +    "where p1.rif_codigo not in "
                              + "(select rif_codigo from registro_llamadas WHERE usuario = " + usuario + " and str_to_date(fecha_llamada,'%d-%m-%Y') >= '"+monday+"' ) "
                      +    "and p1.operadora = " + usuario + " " 
                      +    "and p2.id = p1.operadora "
                      );
              
                while(rs.next()){ 
                    registros[0]= rs.getString("p1.rif_codigo");
                    registros[1]=rs.getString("p1.direccion" );
 
                    model.addRow(registros);     
                }
                
                 tabla.setModel(model);
                 tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            }     
            catch( Exception e){
                   System.out.println("error producido en void listarCliente26"+e.toString());
               }
       
         } 

}


