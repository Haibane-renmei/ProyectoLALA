/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

//Bibliotecas dedicadas a exportar en excel
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;

/**
 *
 * @author Jose
 */
public class Exportar {
    
    //Se crea el ambiente de trabajo, una clase ayudante y las dos hojas del archivo
    private Workbook wb; //Libro de Excel
    private CreationHelper createHelper; // Ayudante de formato
    private CellStyle cellStyle;
    private Sheet sheet1, sheet2; // Hojas del archivo
    private int row1, row2; //Contadores de columnas
    private Row row;
    private Cell cell;

    public Exportar() {
        wb = new HSSFWorkbook(); //Se crea un nuevo libro
        //Workbook wb = new XSSFWorkbook();
        createHelper = wb.getCreationHelper(); //Se complementa el libro creado
        cellStyle = wb.createCellStyle();
        sheet1 = wb.createSheet("Demanda"); //Se crea la pagina de demandas
        sheet2 = wb.createSheet("Llamadas"); //Se crea la pagina de llamadas
        this.row1 = 3;
        this.row2 = 3; 
        initTablas();
    }

    
    private void initTablas(){
        
        // Se establece un formato para las dos hojas de las estadisticas,
        // Primero escribiendo los titulos de las columnas
        
        
        //Se establece el formato para fechas
        cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy"));
        
        //Se inicializa la primera hoja
        row = sheet1.createRow(2);
        row.createCell(0).setCellValue(
         createHelper.createRichTextString("Nombre de producto"));
        row.createCell(1).setCellValue(
         createHelper.createRichTextString("Oferta"));
        row.createCell(2).setCellValue(
         createHelper.createRichTextString("Demanda"));

        
        // Inicializa la segunda hoja
        row = sheet2.createRow((short)2);
        row.createCell(0).setCellValue(
         createHelper.createRichTextString("ID"));
        row.createCell(1).setCellValue(
         createHelper.createRichTextString("Nombre Completo"));
        row.createCell(2).setCellValue(
         createHelper.createRichTextString("Llamadas"));
        row.createCell(3).setCellValue(
         createHelper.createRichTextString("Exitosas"));
        row.createCell(4).setCellValue(
         createHelper.createRichTextString("Promedio exitosas"));
        row.createCell(5).setCellValue(
         createHelper.createRichTextString("Total vendidos"));
        
        
         /*
*/
    }
    
    public void escribirFechas(Date d1, Date d2){
        
        //Al pedir un rango de fechas, se escriben en la primera columna
        // para ambas hojas
        
        cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy"));

        row = sheet1.createRow(0);
        row.createCell(0).setCellValue(
         createHelper.createRichTextString("Entre fechas"));
        cell = row.createCell(1);
        cell.setCellValue(d1);
        cell.setCellStyle(cellStyle);
        
        cell = row.createCell(2);
        cell.setCellValue(d2);
        cell.setCellStyle(cellStyle);

        row = sheet2.createRow(0);
        row.createCell(0).setCellValue(
         createHelper.createRichTextString("Entre fechas"));
        cell = row.createCell(1);
        cell.setCellValue(d1);
        cell.setCellStyle(cellStyle);
        
        cell = row.createCell(2);
        cell.setCellValue(d2);
        cell.setCellStyle(cellStyle);
        

    }
    
    
    public void ingresarDatos(String [] Data, int tabla) throws FileNotFoundException, IOException {
    int i,j;
    
    if (tabla == 0) {
     row = sheet1.createRow(++row1); i = 3;} //         Si es la primera tabla de estadisticas, setear la tabla.
    else {row = sheet2.createRow(++row2); i = 6;} //    y setear el tamano del array, igual con la segunda

    for (j = 0; j < i; j++)
    row.createCell(j).setCellValue(
         createHelper.createRichTextString(Data[j]));
}
    
    public void guardar() throws FileNotFoundException, IOException {
        
    // El sigiente codigo llama a la clase JFileChooser para mostrar una ventana
    // de dialogo, que se presentara al usuario para seleccionar la localizacion
    // de donde quiere guardar el archivo.
    
    JFileChooser chooser = new JFileChooser();
    FileNameExtensionFilter filter = new FileNameExtensionFilter("Microsoft Excel (1997-2003)", "xls", "Excel");
    chooser.setFileFilter(filter);
    chooser.setCurrentDirectory(new java.io.File("."));
    chooser.setDialogTitle("Exportar estadisticas");
    chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    chooser.setAcceptAllFileFilterUsed(false);

    if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
      System.out.println("getCurrentDirectory(): " + chooser.getCurrentDirectory());
      System.out.println("getSelectedFile() : " + chooser.getSelectedFile());
    } else {
      System.out.println("No Selection ");
    }
    
    // Las siguientes lineas ajustan las columnas de las hojas para que quepan
    // las frases.
    // La presencation de esta manera son por razones de rendimiento por parte
    // de los desarrolladores de el api.
        
        sheet1.autoSizeColumn(0);
        sheet1.autoSizeColumn(1);
        sheet1.autoSizeColumn(2);
        sheet1.setColumnWidth(1, 3000);
        
        sheet2.autoSizeColumn(0);
        sheet2.autoSizeColumn(1);
        sheet2.autoSizeColumn(2);
        sheet2.autoSizeColumn(3);
        sheet2.autoSizeColumn(4);
        sheet2.autoSizeColumn(5);
        
    //Con la selecion del filechooser, se guarda el archivo.
    FileOutputStream fileOut = new FileOutputStream(chooser.getSelectedFile()+".xls");
    wb.write(fileOut);
    fileOut.close();
}
    
    public void Limpiar() {
        this.wb = new HSSFWorkbook(); //Se limpia el libro
        this.createHelper = wb.getCreationHelper(); //Se complementa el libro creado
        this.cellStyle = wb.createCellStyle();
        this.sheet1 = wb.createSheet("Demanda"); //Se limpia la pagina de demandas
        this.sheet2 = wb.createSheet("Llamadas"); //Se limpia la pagina de llamadas
        this.row1 = 3;
        this.row2 = 3;
        initTablas();
}
    
    
    
    

    
}
